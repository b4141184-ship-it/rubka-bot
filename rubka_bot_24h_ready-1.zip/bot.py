from rubka import Robot, Message
import re
import time
import json
import os
import asyncio
import random
from datetime import datetime

# ==================================================
# تنظیمات
# ==================================================

# توکن قبلی که داخل چت فرستاده شد را استفاده نکن.
# یک توکن جدید بساز و در متغیر محیطی RUBKA_TOKEN قرار بده.
TOKEN = os.getenv("RUBKA_TOKEN", "YOUR_NEW_BOT_TOKEN")

BOT_OWNER = "@KAPITAN1h"

bot = Robot(
    token=TOKEN,
    safeSendMode=True
)

# ==================================================
# فایل آمار
# ==================================================

STATS_FILE = "stats.json"

GROUPS = {}

DEFAULT_LOCKS = {
    "link": False,
    "id": False,
    "spam": False,
    "number": False,
}

USER_MESSAGES = {}

STATS_DIRTY = False
LAST_SAVE = 0
SAVE_INTERVAL = 5

# ==================================================
# Regexها
# ==================================================

LINK_PATTERN = re.compile(
    r"https?://\S+"
    r"|www\.\S+"
    r"|t\.me/\S+"
    r"|telegram\.me/\S+"
    r"|rubika\.ir/\S+",
    re.IGNORECASE
)

ID_PATTERN = re.compile(
    r"@\w+",
    re.IGNORECASE
)

PHONE_PATTERN = re.compile(
    r"09\d{9}"
    r"|\+98\d{10}"
    r"|0098\d{10}"
)

# ==================================================
# نرمال‌سازی متن
# ==================================================

def normalize_text(text):
    text = str(text or "").strip()

    # تبدیل حروف عربی به فارسی
    text = text.replace("ي", "ی")
    text = text.replace("ى", "ی")
    text = text.replace("ك", "ک")

    # فاصله‌های اضافه
    text = re.sub(r"\s+", " ", text)

    return text.strip()

# ==================================================
# پاسخ‌های سخنگو
# ==================================================

SPEAKERS = {
    "سلام": [
        "سلام 👋🌹",
        "سلام رفیق ❤️",
        "درود بر تو 😎",
        "سلام، خوش اومدی 🤖🌹",
    ],

    "خوبی": [
        "مرسی رفیق، من خوبم 😎❤️",
        "عالی‌ام 🤖🔥 تو چطوری؟",
        "خوبم، آماده‌ام 😁",
    ],

    "چطوری": [
        "خوبم رفیق 😎❤️",
        "عالی‌ام، مرسی که پرسیدی 🌹",
        "رو به راهم 🤖🔥",
    ],

    "صبح بخیر": [
        "صبح بخیر 🌞🌹",
        "صبحت عالی رفیق ☀️❤️",
        "صبح قشنگی داشته باشی 😎",
    ],

    "شب بخیر": [
        "شب بخیر 🌙❤️",
        "شبت آروم و قشنگ 🌙✨",
        "شب خوبی داشته باشی 🌹",
    ],

    "خداحافظ": [
        "خداحافظ رفیق 👋❤️",
        "فعلاً، مراقب خودت باش 🌹",
        "به امید دیدار 👋😎",
    ],

    "ربات": [
        "جانم؟ 🤖",
        "بله رفیق؟ 😎",
        "اینجام 👋🤖",
        "گوشم بهت هست 😁",
    ],

    "کجایی": [
        "همین‌جام رفیق 🤖😂",
        "توی گروه، آماده‌ام 😎",
        "اینجام 👀🤖",
    ],

    "چه خبر": [
        "خبر خاصی نیست، همه‌چی مرتبه 😎",
        "همه‌چی آرومه 🤖🔥",
        "فعلاً که اوضاع خوبه 🌹",
    ],

    "مرسی": [
        "خواهش می‌کنم ❤️",
        "قابلی نداشت رفیق 🌹",
        "خواهش رفیق 😎",
    ],

    "ممنون": [
        "خواهش می‌کنم ❤️",
        "قربانت 🌹",
        "اختیار داری 😎",
    ],

    "دمت گرم": [
        "قربانت رفیق 😎❤️",
        "فدات 🔥",
        "دمت گرم خودت 😁",
    ],

    "عشقی": [
        "عشقی خودتی ❤️🔥",
        "قربونت رفیق 😎",
        "مرسی ❤️",
    ],

    "آفرین": [
        "مرسی رفیق 😎❤️",
        "دمت گرم 🌹",
        "لطف داری 😁",
    ],

    "بیداری": [
        "آره، آنلاینم 🤖👀",
        "بیدارم رفیق 😎",
        "کاملاً آنلاینم 🔥",
    ],

    "فعالی": [
        "بله، کاملاً فعالم 🤖🔥",
        "آنلاین و آماده‌ام 😎",
        "فعال و آماده دریافت دستورم ✅",
    ],

    "کمک": [
        "برای دیدن دستورات «راهنما» رو بفرست 📖",
        "دستور «راهنما» رو بفرست تا لیست امکانات رو ببینی 🤖",
    ],

    "تست": [
        "✅ تست با موفقیت انجام شد.",
        "🏓 اوکیه، ربات سالمه 🤖",
    ],

    "خسته نباشی": [
        "قربانت 🌹❤️",
        "ممنون رفیق 😎",
        "لطف داری ❤️",
    ],

    "خسته نباشید": [
        "ممنون 🌹",
        "قربانت رفیق ❤️",
    ],
}

# ==================================================
# خواندن آمار
# ==================================================

def load_stats():
    if not os.path.exists(STATS_FILE):
        return {"groups": {}}

    try:
        with open(STATS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, dict):
            return {"groups": {}}

        if "groups" not in data:
            data["groups"] = {}

        return data

    except Exception as e:
        print("LOAD STATS ERROR:", repr(e))
        return {"groups": {}}


STATS = load_stats()

# ==================================================
# ذخیره آمار
# ==================================================

def save_stats(force=False):
    global STATS_DIRTY
    global LAST_SAVE

    now = time.time()

    if not force:
        if not STATS_DIRTY:
            return

        if now - LAST_SAVE < SAVE_INTERVAL:
            return

    try:
        temp_file = STATS_FILE + ".tmp"

        with open(temp_file, "w", encoding="utf-8") as f:
            json.dump(
                STATS,
                f,
                ensure_ascii=False,
                separators=(",", ":")
            )

        os.replace(temp_file, STATS_FILE)

        STATS_DIRTY = False
        LAST_SAVE = now

    except Exception as e:
        print("SAVE STATS ERROR:", repr(e))


def mark_stats_dirty():
    global STATS_DIRTY
    STATS_DIRTY = True


async def stats_saver():
    while True:
        try:
            save_stats()
        except Exception as e:
            print("AUTO SAVE ERROR:", repr(e))

        await asyncio.sleep(SAVE_INTERVAL)

# ==================================================
# ساخت آمار گروه
# ==================================================

def get_group_stats(chat_id):
    chat_id = str(chat_id)
    groups = STATS["groups"]

    if chat_id not in groups:
        groups[chat_id] = {
            "total_messages": 0,
            "deleted_links": 0,
            "deleted_ids": 0,
            "deleted_numbers": 0,
            "deleted_spam": 0,
            "total_warnings": 0,
            "users": {}
        }
        mark_stats_dirty()

    return groups[chat_id]

# ==================================================
# ساخت آمار کاربر
# ==================================================

def get_user_stats(chat_id, user_id):
    group = get_group_stats(chat_id)
    user_id = str(user_id)

    if user_id not in group["users"]:
        group["users"][user_id] = {
            "messages": 0,
            "warnings": 0,
            "deleted_links": 0,
            "deleted_ids": 0,
            "deleted_numbers": 0,
            "deleted_spam": 0
        }
        mark_stats_dirty()

    return group["users"][user_id]

# ==================================================
# اطلاعات گروه
# ==================================================

def get_group(chat_id):
    chat_id = str(chat_id)

    if chat_id not in GROUPS:
        GROUPS[chat_id] = {
            "locks": DEFAULT_LOCKS.copy(),
            "chat_closed": False
        }

    return GROUPS[chat_id]

# ==================================================
# شناسه کاربر
# ==================================================

def get_user_id(message):
    try:
        value = getattr(message, "sender_id", None)

        if value:
            return str(value)

    except Exception:
        pass

    try:
        raw = getattr(message, "raw_data", {})

        if isinstance(raw, dict):
            for key in ("sender_id", "user_id", "author_id"):
                value = raw.get(key)

                if value:
                    return str(value)

    except Exception:
        pass

    return None

# ==================================================
# شناسه کاربر ریپلای شده
# این بخش فقط برای مدیریت کاربر استفاده می‌شود.
# پاسخ‌های معمولی ربات دیگر Reply نیستند.
# ==================================================

def get_reply_user_id(message):
    try:
        raw = getattr(message, "raw_data", {})

        if not isinstance(raw, dict):
            return None

        reply = (
            raw.get("reply_to_message")
            or raw.get("reply_to")
            or raw.get("reply_message")
        )

        if isinstance(reply, dict):
            for key in ("sender_id", "user_id", "author_id"):
                value = reply.get(key)

                if value:
                    return str(value)

            sender = reply.get("sender")

            if isinstance(sender, dict):
                for key in ("user_id", "id", "guid"):
                    value = sender.get(key)

                    if value:
                        return str(value)

    except Exception as e:
        print("REPLY USER ERROR:", repr(e))

    return None

# ==================================================
# پاسخ بدون Reply
# ==================================================

async def reply(message, text):
    """
    عمداً از message.reply استفاده نمی‌کنیم.
    پیام به صورت عادی داخل همان چت ارسال می‌شود.
    """
    try:
        chat_id = str(getattr(message, "chat_id", ""))

        if not chat_id:
            return False

        await bot.send_message(
            chat_id,
            str(text)
        )

        return True

    except Exception as e:
        print("SEND ERROR:", repr(e))
        return False

# ==================================================
# حذف پیام
# ==================================================

async def delete_message(message):
    try:
        chat_id = str(message.chat_id)

        message_id = getattr(
            message,
            "message_id",
            None
        )

        if not message_id:
            return False

        await bot.delete_message(
            chat_id,
            str(message_id)
        )

        print("MESSAGE DELETED:", message_id)
        return True

    except Exception as e:
        print("DELETE ERROR:", repr(e))
        return False

# ==================================================
# تشخیص‌ها
# ==================================================

def has_link(text):
    return bool(LINK_PATTERN.search(text))


def has_id_or_mention(text):
    return bool(ID_PATTERN.search(text))


def has_phone(text):
    return bool(PHONE_PATTERN.search(text))


def is_spam(message):
    user_id = get_user_id(message)

    if not user_id:
        return False

    now = time.time()

    messages = USER_MESSAGES.get(user_id)

    if messages is None:
        messages = []
        USER_MESSAGES[user_id] = messages

    messages.append(now)

    cutoff = now - 10

    USER_MESSAGES[user_id] = [
        timestamp
        for timestamp in messages
        if timestamp >= cutoff
    ]

    # 6 پیام یا بیشتر در 10 ثانیه
    return len(USER_MESSAGES[user_id]) >= 6

# ==================================================
# راهنما
# ==================================================

HELP_TEXT = """
╔════════════════════════════╗
       🤖 راهنمای کامل ربات
╚════════════════════════════╝

🗣️ سخنگو
━━━━━━━━━━━━━━━━━━━━
سلام
خوبی
چطوری
ربات
کجایی
چه خبر
مرسی
ممنون
دمت گرم
عشقی
آفرین
بیداری
فعالی
کمک

🔐 قفل‌های گروه
━━━━━━━━━━━━━━━━━━━━
🔗 قفل لینک
🔓 لینک باز

🆔 قفل آیدی
🔓 آیدی باز

📛 قفل اسپم
🔓 اسپم باز

📱 قفل شماره
🔓 شماره باز

💬 گپ بسته
🔓 گپ باز

📋 لیست قفل

👮 مدیریت کاربران
━━━━━━━━━━━━━━━━━━━━
🚫 بن
روی پیام کاربر ریپلای + «بن»

✅ رفع بن
روی پیام کاربر ریپلای + «رفع بن»

⚠️ اخطار
روی پیام کاربر ریپلای + «اخطار»

➖ حذف اخطار
روی پیام کاربر ریپلای + «حذف اخطار»

🔢 اخطارها

📊 آمار
━━━━━━━━━━━━━━━━━━━━
📊 آمار من
📊 آمار کاربر
📊 آمار گروه
🗑️ ریست آمار

ℹ️ عمومی
━━━━━━━━━━━━━━━━━━━━
🏓 پینگ
🆔 شناسه
🆔 آیدی گروه
🤖 وضعیت
🧪 تست
🕐 ساعت
📅 تاریخ
👑 مالک
📜 قوانین
📖 راهنما

⚠️ برای حذف پیام و مدیریت اعضا،
ربات باید دسترسی لازم را داشته باشد.
"""

# ==================================================
# هندلر اصلی
# ==================================================

@bot.on_message()
async def main(bot_instance, message: Message):

    try:
        chat_id = str(
            getattr(message, "chat_id", "")
        )

        text = normalize_text(
            getattr(message, "text", "")
        )

        if not chat_id or not text:
            return

        user_id = get_user_id(message)

        print("MESSAGE:", text)
        print("CHAT ID:", chat_id)

        # ==================================================
        # آمار پیام
        # ==================================================

        group_stats = get_group_stats(chat_id)

        group_stats["total_messages"] += 1

        if user_id:
            user_stats = get_user_stats(
                chat_id,
                user_id
            )
            user_stats["messages"] += 1

        mark_stats_dirty()

        # ==================================================
        # گروه
        # ==================================================

        group = get_group(chat_id)
        locks = group["locks"]

        # ==================================================
        # سخنگو
        # ==================================================

        if text in SPEAKERS:
            await reply(
                message,
                random.choice(SPEAKERS[text])
            )
            return

        # ==================================================
        # راهنما
        # ==================================================

        if text in (
            "راهنما",
            "/راهنما",
            "help",
            "/help"
        ):
            await reply(message, HELP_TEXT)
            return

        # ==================================================
        # پینگ
        # ==================================================

        if text in ("پینگ", "/پینگ", "ping", "/ping"):
            await reply(
                message,
                "🏓 پینگ!\n🤖 ربات آنلاین است."
            )
            return

        # ==================================================
        # شناسه
        # ==================================================

        if text in ("شناسه", "/شناسه"):
            await reply(
                message,
                "🆔 شناسه شما:\n"
                f"{user_id or 'نامشخص'}"
            )
            return

        # ==================================================
        # آیدی گروه
        # ==================================================

        if text in ("آیدی گروه", "شناسه گروه"):
            await reply(
                message,
                "🆔 شناسه گروه:\n"
                f"{chat_id}"
            )
            return

        # ==================================================
        # فعال
        # ==================================================

        if text in ("فعال", "/فعال"):
            await reply(
                message,
                "🤖 ربات فعال شد.\n\n"
                "🟢 سیستم مدیریت آماده است.\n"
                "⚡ ضدلینک آماده است.\n"
                "📛 ضداسپم آماده است.\n"
                f"👑 مالک ربات: {BOT_OWNER}"
            )
            return

        # ==================================================
        # وضعیت
        # ==================================================

        if text in ("وضعیت", "وضعیت ربات"):
            await reply(
                message,
                "🤖 وضعیت ربات\n"
                "━━━━━━━━━━━━\n"
                "🟢 آنلاین\n"
                "⚡ آماده دریافت دستور\n"
                f"👑 مالک: {BOT_OWNER}"
            )
            return

        # ==================================================
        # تست
        # ==================================================

        if text in ("تست", "تست ربات"):
            await reply(
                message,
                "✅ تست با موفقیت انجام شد."
            )
            return

        # ==================================================
        # ساعت
        # ==================================================

        if text in ("ساعت", "زمان"):
            await reply(
                message,
                "🕐 ساعت فعلی سیستم:\n"
                f"{datetime.now().strftime('%H:%M:%S')}"
            )
            return

        # ==================================================
        # تاریخ
        # ==================================================

        if text in ("تاریخ", "امروز"):
            await reply(
                message,
                "📅 تاریخ سیستم:\n"
                f"{datetime.now().strftime('%Y-%m-%d')}"
            )
            return

        # ==================================================
        # مالک
        # ==================================================

        if text in ("مالک", "صاحب ربات"):
            await reply(
                message,
                f"👑 مالک ربات:\n{BOT_OWNER}"
            )
            return

        # ==================================================
        # قوانین
        # ==================================================

        if text in ("قوانین", "قانون"):
            await reply(
                message,
                "📜 قوانین گروه\n"
                "━━━━━━━━━━━━\n"
                "1️⃣ احترام به اعضا\n"
                "2️⃣ عدم ارسال لینک در صورت فعال بودن قفل\n"
                "3️⃣ عدم ارسال اسپم\n"
                "4️⃣ عدم ارسال شماره در صورت فعال بودن قفل\n"
                "5️⃣ رعایت نظم گروه ❤️"
            )
            return

        # ==================================================
        # قفل لینک
        # ==================================================

        if text == "قفل لینک":
            locks["link"] = True

            await reply(
                message,
                "🔒 قفل لینک فعال شد."
            )
            return

        if text == "لینک باز":
            locks["link"] = False

            await reply(
                message,
                "🔓 قفل لینک باز شد."
            )
            return

        # ==================================================
        # قفل آیدی
        # ==================================================

        if text == "قفل آیدی":
            locks["id"] = True

            await reply(
                message,
                "🔒 قفل آیدی/منشن فعال شد."
            )
            return

        if text == "آیدی باز":
            locks["id"] = False

            await reply(
                message,
                "🔓 قفل آیدی/منشن باز شد."
            )
            return

        # ==================================================
        # قفل شماره
        # ==================================================

        if text == "قفل شماره":
            locks["number"] = True

            await reply(
                message,
                "🔒 قفل شماره فعال شد."
            )
            return

        if text == "شماره باز":
            locks["number"] = False

            await reply(
                message,
                "🔓 قفل شماره باز شد."
            )
            return

        # ==================================================
        # قفل اسپم
        # ==================================================

        if text == "قفل اسپم":
            locks["spam"] = True

            await reply(
                message,
                "📛 قفل اسپم فعال شد."
            )
            return

        if text == "اسپم باز":
            locks["spam"] = False

            await reply(
                message,
                "🔓 قفل اسپم باز شد."
            )
            return

        # ==================================================
        # لیست قفل
        # ==================================================

        if text == "لیست قفل":

            link = "🔒 فعال" if locks["link"] else "🔓 خاموش"
            ident = "🔒 فعال" if locks["id"] else "🔓 خاموش"
            spam = "🔒 فعال" if locks["spam"] else "🔓 خاموش"
            number = "🔒 فعال" if locks["number"] else "🔓 خاموش"

            await reply(
                message,
                "📋 وضعیت قفل‌ها\n"
                "━━━━━━━━━━━━━━\n"
                f"🔗 لینک: {link}\n"
                f"🆔 آیدی: {ident}\n"
                f"📛 اسپم: {spam}\n"
                f"📱 شماره: {number}"
            )
            return

        # ==================================================
        # آمار من
        # ==================================================

        if text in ("آمار من", "امار من"):

            if not user_id:
                await reply(
                    message,
                    "❌ شناسه کاربر پیدا نشد."
                )
                return

            stats = get_user_stats(
                chat_id,
                user_id
            )

            await reply(
                message,
                "📊 آمار شما\n"
                "━━━━━━━━━━━━━━\n"
                f"🆔 شناسه: {user_id}\n"
                f"💬 تعداد پیام: {stats['messages']}\n"
                f"⚠️ اخطار: {stats['warnings']}\n"
                f"🔗 لینک حذف‌شده: {stats['deleted_links']}\n"
                f"🆔 آیدی حذف‌شده: {stats['deleted_ids']}\n"
                f"📱 شماره حذف‌شده: {stats['deleted_numbers']}\n"
                f"📛 اسپم حذف‌شده: {stats['deleted_spam']}"
            )
            return

        # ==================================================
        # آمار کاربر
        # ==================================================

        if text in ("آمار کاربر", "امار کاربر"):

            target_id = get_reply_user_id(message)

            if not target_id:
                await reply(
                    message,
                    "⚠️ برای آمار کاربر، روی پیام همان کاربر ریپلای کن."
                )
                return

            stats = get_user_stats(
                chat_id,
                target_id
            )

            await reply(
                message,
                "📊 آمار کاربر\n"
                "━━━━━━━━━━━━━━\n"
                f"🆔 شناسه: {target_id}\n"
                f"💬 تعداد پیام: {stats['messages']}\n"
                f"⚠️ اخطار: {stats['warnings']}\n"
                f"🔗 لینک حذف‌شده: {stats['deleted_links']}\n"
                f"🆔 آیدی حذف‌شده: {stats['deleted_ids']}\n"
                f"📱 شماره حذف‌شده: {stats['deleted_numbers']}\n"
                f"📛 اسپم حذف‌شده: {stats['deleted_spam']}"
            )
            return

        # ==================================================
        # آمار گروه
        # ==================================================

        if text in ("آمار گروه", "امار گروه"):

            users_count = len(
                group_stats["users"]
            )

            await reply(
                message,
                "📊 آمار گروه\n"
                "━━━━━━━━━━━━━━━━\n"
                f"💬 کل پیام‌ها: {group_stats['total_messages']}\n"
                f"👥 کاربران ثبت‌شده: {users_count}\n"
                f"🔗 لینک حذف‌شده: {group_stats['deleted_links']}\n"
                f"🆔 آیدی حذف‌شده: {group_stats['deleted_ids']}\n"
                f"📱 شماره حذف‌شده: {group_stats['deleted_numbers']}\n"
                f"📛 اسپم حذف‌شده: {group_stats['deleted_spam']}\n"
                f"⚠️ کل اخطارها: {group_stats['total_warnings']}"
            )
            return

        # ==================================================
        # اخطار
        # ==================================================

        if text in ("اخطار", "هشدار"):

            target_id = get_reply_user_id(message)

            if not target_id:
                await reply(
                    message,
                    "⚠️ برای اخطار، روی پیام کاربر ریپلای کن."
                )
                return

            stats = get_user_stats(
                chat_id,
                target_id
            )

            stats["warnings"] += 1
            group_stats["total_warnings"] += 1

            mark_stats_dirty()

            await reply(
                message,
                "⚠️ اخطار ثبت شد.\n\n"
                f"🆔 کاربر: {target_id}\n"
                f"⚠️ تعداد اخطار: {stats['warnings']}"
            )
            return

        # ==================================================
        # حذف اخطار
        # ==================================================

        if text in ("حذف اخطار", "کسر اخطار"):

            target_id = get_reply_user_id(message)

            if not target_id:
                await reply(
                    message,
                    "⚠️ برای حذف اخطار، روی پیام کاربر ریپلای کن."
                )
                return

            stats = get_user_stats(
                chat_id,
                target_id
            )

            if stats["warnings"] > 0:
                stats["warnings"] -= 1

                if group_stats["total_warnings"] > 0:
                    group_stats["total_warnings"] -= 1

                mark_stats_dirty()

            await reply(
                message,
                "➖ یک اخطار حذف شد.\n\n"
                f"🆔 کاربر: {target_id}\n"
                f"⚠️ اخطار فعلی: {stats['warnings']}"
            )
            return

        # ==================================================
        # تعداد اخطار
        # ==================================================

        if text in ("اخطارها", "تعداد اخطار"):

            target_id = get_reply_user_id(message)

            if not target_id:
                target_id = user_id

            if not target_id:
                await reply(
                    message,
                    "❌ کاربر پیدا نشد."
                )
                return

            stats = get_user_stats(
                chat_id,
                target_id
            )

            await reply(
                message,
                "⚠️ وضعیت اخطار\n"
                "━━━━━━━━━━━━\n"
                f"🆔 کاربر: {target_id}\n"
                f"⚠️ تعداد اخطار: {stats['warnings']}"
            )
            return

        # ==================================================
        # ریست آمار
        # ==================================================

        if text in ("ریست آمار", "ریست امار"):

            STATS["groups"][chat_id] = {
                "total_messages": 0,
                "deleted_links": 0,
                "deleted_ids": 0,
                "deleted_numbers": 0,
                "deleted_spam": 0,
                "total_warnings": 0,
                "users": {}
            }

            mark_stats_dirty()
            save_stats(force=True)

            await reply(
                message,
                "🗑️ آمار گروه صفر شد."
            )
            return

        # ==================================================
        # گپ
        # ==================================================

        if text == "گپ بسته":
            group["chat_closed"] = True

            await reply(
                message,
                "🔒 حالت گپ بسته فعال شد."
            )
            return

        if text == "گپ باز":
            group["chat_closed"] = False

            await reply(
                message,
                "🔓 حالت گپ باز شد."
            )
            return

        # ==================================================
        # بن
        # ==================================================

        if text == "بن":

            target_id = get_reply_user_id(message)

            if not target_id:
                await reply(
                    message,
                    "⚠️ برای بن، روی پیام کاربر ریپلای کن."
                )
                return

            try:
                await bot.ban_member_chat(
                    chat_id,
                    target_id
                )

                await reply(
                    message,
                    "🚫 کاربر بن شد."
                )

            except Exception as e:
                print("BAN ERROR:", repr(e))

                await reply(
                    message,
                    "❌ بن انجام نشد.\n"
                    "مطمئن شو ربات دسترسی ادمین دارد."
                )

            return

        # ==================================================
        # رفع بن
        # ==================================================

        if text in (
            "رفع بن",
            "انبن",
            "رفع مسدودیت"
        ):

            target_id = get_reply_user_id(message)

            if not target_id:
                await reply(
                    message,
                    "⚠️ برای رفع بن، روی پیام کاربر ریپلای کن."
                )
                return

            try:
                await bot.unban_chat_member(
                    chat_id,
                    target_id
                )

                await reply(
                    message,
                    "✅ مسدودیت کاربر برداشته شد."
                )

            except Exception as e:
                print("UNBAN ERROR:", repr(e))

                await reply(
                    message,
                    "❌ رفع مسدودیت انجام نشد."
                )

            return

        # ==================================================
        # ضد لینک
        # ==================================================

        if locks["link"] and has_link(text):

            deleted = await delete_message(message)

            if deleted:
                group_stats["deleted_links"] += 1

                if user_id:
                    get_user_stats(
                        chat_id,
                        user_id
                    )["deleted_links"] += 1

                mark_stats_dirty()

            return

        # ==================================================
        # ضد آیدی
        # ==================================================

        if locks["id"] and has_id_or_mention(text):

            deleted = await delete_message(message)

            if deleted:
                group_stats["deleted_ids"] += 1

                if user_id:
                    get_user_stats(
                        chat_id,
                        user_id
                    )["deleted_ids"] += 1

                mark_stats_dirty()

            return

        # ==================================================
        # ضد شماره
        # ==================================================

        if locks["number"] and has_phone(text):

            deleted = await delete_message(message)

            if deleted:
                group_stats["deleted_numbers"] += 1

                if user_id:
                    get_user_stats(
                        chat_id,
                        user_id
                    )["deleted_numbers"] += 1

                mark_stats_dirty()

            return

        # ==================================================
        # ضد اسپم
        # ==================================================

        if locks["spam"] and is_spam(message):

            deleted = await delete_message(message)

            if deleted:
                group_stats["deleted_spam"] += 1

                if user_id:
                    get_user_stats(
                        chat_id,
                        user_id
                    )["deleted_spam"] += 1

                mark_stats_dirty()

            return

    except Exception as e:
        print("MAIN ERROR:", repr(e))

# ==================================================
# اجرای ربات
# ==================================================

print("================================")
print("🤖 RUBKA FAST BOT STARTED")
print("================================")
print("⚡ نسخه سریع فعال است")
print("🗣️ سخنگو فعال است")
print("🔕 پاسخ‌ها بدون Reply ارسال می‌شوند")
print("================================")

try:
    loop = asyncio.get_event_loop()

    loop.create_task(
        stats_saver()
    )

except Exception as e:
    print(
        "AUTO SAVE START ERROR:",
        repr(e)
    )

bot.run()
